# Be The Coach Basketball — Android app source

This is a mobile-first Expo / React Native rebuild inspired by the supplied browser prototype. The supplied HTML file ended mid-function, so the Android app is a clean native implementation of its dynasty-management concept rather than a direct WebView wrapper.

## Included gameplay
- Choose from six conferences and 90 real college programs from the supplied prototype data.
- Start a dynasty with a fictional roster and persistent career save.
- Manage starters, recruit fictional prospects, manage NIL credits, and set offensive/defensive strategy and training focus.
- Play/simulate a 14-game season, track records, player stats, fatigue and morale, and advance seasons.
- Local autosave using AsyncStorage; no account or network required.

## Run locally
1. Install Node.js LTS and Android Studio (or use Expo Go for a quick device preview).
2. In this folder run `npm install`.
3. Run `npx expo start` and scan the QR code with Expo Go, or run `npx expo run:android` with an Android emulator/device connected.

## Build Android release
1. Install EAS CLI: `npm install -g eas-cli`.
2. Sign in: `eas login`.
3. Configure the project: `eas build:configure`.
4. Build a test APK: `eas build --platform android --profile preview`.
5. Build the Play Store bundle: `eas build --platform android --profile production`.
6. Upload the resulting `.aab` in Google Play Console and complete the store listing, content rating, data safety, target audience, and testing declarations.

## Before public release
- Replace the placeholder Android package ID `com.betthecoach.basketball` if you want a different permanent ID (must be unique; changing it after publication is not straightforward).
- Add a finished icon, feature graphic, screenshots, privacy policy URL, support contact, and store description.
- Thoroughly QA game balance, roster logic, tournament progression, save migration, accessibility, and device layouts. This is an initial playable foundation, not a certified or fully QA'd commercial release.
- Verify any college team names, logos, marks, and other third-party IP against Google Play policies and applicable licensing. The app intentionally does not bundle school logos.
